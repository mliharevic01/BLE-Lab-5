/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>


int main()
{
       uint8 ch;
      uint8 num =1;
      int i = 0;
      
    
    UART_Start();
    UART_UartPutString("CY8CKIT-042-BLE");
  //  Pin_Red_Write(~Pin_Red_Read());
    
           // Pin_1_Write(Pin_1_Read());
      //  if(Pin_1_Read())
        //{
          //  i = 1;
           // Pin_Red_Write(~Pin_Red_Read());
       // }
        
        //if(i ==1)
        //{
            Pin_Red_Write(Pin_1_Read());  
     //   }
  
    for(;;)
    { 
        
       
        ch = UART_UartGetChar();
        if(0u != ch)
        {
              UART_UartPutChar(ch);
         }
          
    }
}
/* [] END OF FILE */
